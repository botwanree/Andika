const fs = require('fs')
const chalk = require('chalk')

global.owner = "6285805080983"
global.namabot = "BOTZ-DEFZ"
global.namaCreator = "DEFZOFFC"
global.autoJoin = true
global.antilink = false
global.versisc = '3.0.0'
global.codeInvite = "FxHYWIP1p8ZA8nuC0ZGJHv" //JANGAN DI UBAH 
global.domain = 'https://pecintaloli.serverpannel.biz.id' // Isi Domain Lu
global.apikey = 'ptla_u6fuKnNFJFFxrZ0CFSFK7PgjtzovrlQ4Vl5qwwTWybg' // Isi Apikey Plta Lu
global.capikey = 'ptlc_DW3tsU1uOfkzTyf2tU4FHK7u77QrLexXsQyUGEOiJ5L' // Isi Apikey Pltc Lu
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location
global.imageurl = 'https://telegra.ph/file/917f9a6ef0b25bcafd8fe.jpg'
global.isLink = 'https://chat.whatsapp.com/JOqYiEAKXBpLyKy0TbW48m'
global.thumb = fs.readFileSync("./thumb.png")
global.audionya = fs.readFileSync("./all/sound.mp3")
global.simbol = '∮'
global.tekspushkon = ""
global.tekspushkonv2 = ""
global.packname = "© Created DEFZOFFC"
global.author = "DEFZOFFC"
global.jumlah = "5"

//=================================================//
//Gausah Juga
global.limitawal = {
    premium: "Infinity",
    free: 100
}
//=================================================//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})